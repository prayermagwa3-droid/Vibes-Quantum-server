# Build-only worker image. Build from trusted CI, pin this base image by digest for production.
# Project tests execute with --network=none, no host secrets, dropped capabilities and a read-only root FS.
FROM gradle:9.6.1-jdk17

USER root
ENV DEBIAN_FRONTEND=noninteractive \
    ANDROID_HOME=/opt/android-sdk \
    ANDROID_SDK_ROOT=/opt/android-sdk \
    JAVA_TOOL_OPTIONS=-Dfile.encoding=UTF-8
ENV PATH="${PATH}:/opt/android-sdk/cmdline-tools/latest/bin:/opt/android-sdk/platform-tools"

RUN apt-get update \
    && apt-get install -y --no-install-recommends \
       ca-certificates curl unzip zip git python3 python3-pytest nodejs npm \
       maven golang-go rustc cargo build-essential \
    && rm -rf /var/lib/apt/lists/*

# Official Android command-line tools download + SHA-256 verification (Linux package).
ARG ANDROID_CMDLINE_TOOLS_REVISION=15859902
ARG ANDROID_CMDLINE_TOOLS_SHA256=4e4c464f145a7512b57d088ac6c278c03c9eea610886b35a5e0804e74eedf583
RUN mkdir -p "${ANDROID_HOME}/cmdline-tools" /tmp/android-cli \
    && curl --fail --location --retry 3 \
       "https://dl.google.com/android/repository/commandlinetools-linux-${ANDROID_CMDLINE_TOOLS_REVISION}_latest.zip" \
       --output /tmp/android-cli.zip \
    && echo "${ANDROID_CMDLINE_TOOLS_SHA256}  /tmp/android-cli.zip" | sha256sum --check - \
    && unzip -q /tmp/android-cli.zip -d /tmp/android-cli \
    && mv /tmp/android-cli/cmdline-tools "${ANDROID_HOME}/cmdline-tools/latest" \
    && rm -rf /tmp/android-cli /tmp/android-cli.zip \
    && yes | sdkmanager --sdk_root="${ANDROID_HOME}" --licenses >/dev/null \
    && sdkmanager --sdk_root="${ANDROID_HOME}" \
       "platform-tools" "platforms;android-35" "platforms;android-36" \
       "build-tools;35.0.0" "build-tools;36.0.0" \
    && chmod -R a+rX "${ANDROID_HOME}"

# Admin-built images may populate these directories with vetted, offline-only dependency
# caches for the exact projects they intend to support. The runner copies caches into a
# writable tmpfs home; it never mounts cache directories writable into an untrusted build.
RUN mkdir -p /opt/vibes/cache/gradle /opt/vibes/cache/npm /opt/vibes/cache/maven-repository \
             /opt/vibes/cache/cargo /opt/vibes/cache/go-mod \
    && chmod -R a+rX /opt/vibes/cache

# The container runtime overrides user, temporary home, limits and network policy.
WORKDIR /workspace
USER 65534:65534
