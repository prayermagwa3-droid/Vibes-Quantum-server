package com.vibes.quantum.server.quality

import kotlinx.serialization.Serializable
import java.time.Instant
import java.util.UUID
import kotlin.math.max

@Serializable data class EvalCase(val id:String, val category:String, val prompt:String, val reference:String, val candidateAnswer:String="", val critical:Boolean=false, val rubric:String="Exact/reference comparison")
@Serializable data class EvalRunRequest(val engineVersion:String, val datasetVersion:String, val providerIds:List<String> = emptyList(), val configurationId:String="default", val cases:List<EvalCase>, val sampleSize:Int=100, val baselineScore:Double?=null, val candidateScore:Double, val criticalFailures:Int=0, val privacySecurityPassed:Boolean=true, val avgLatencyMs:Long=0, val providerFailures:Int=0, val estimatedCost:Double=0.0)
@Serializable data class EvalRun(val id:String,val createdAt:String,val engineVersion:String,val datasetVersion:String,val configurationId:String,val providerIds:List<String>,val evaluated:Int,val sampleRequested:Int,val candidateScore:Double,val baselineScore:Double?,val regressionRate:Double,val criticalFailures:Int,val privacySecurityPassed:Boolean,val avgLatencyMs:Long,val providerFailures:Int,val estimatedCost:Double,val promoted:Boolean,val gateReasons:List<String>,val reviewRequired:Int)
@Serializable data class ReviewItem(val id:String,val kind:String,val subject:String,val reason:String,val createdAt:String,val status:String="pending")

/** In-memory reference implementation. Production deployments should supply a durable database adapter. */
class QualityGateService(private val maxHistory:Int=500) {
 private val runs= arrayListOf<EvalRun>(); private val reviews= arrayListOf<ReviewItem>()
 @Synchronized fun evaluate(r:EvalRunRequest):EvalRun {
  require(r.engineVersion.isNotBlank() && r.datasetVersion.isNotBlank()); require(r.cases.isNotEmpty()); require(r.sampleSize in 1..10000)
  require(r.candidateScore in 0.0..1.0); require(r.baselineScore==null || r.baselineScore in 0.0..1.0)
  val sampled=r.cases.take(minOf(r.sampleSize,r.cases.size)); val n=sampled.size; val reasons= mutableListOf<String>()
  val scored=sampled.filter { it.reference.isNotBlank() && it.candidateAnswer.isNotBlank() }
  val measured=if(scored.isEmpty()) 0.0 else scored.count { normalize(it.reference)==normalize(it.candidateAnswer) }.toDouble()/scored.size
  if(scored.size<n) reasons += "Some sampled cases lack candidate answers or expert references"
  val regression= r.baselineScore?.let { max(0.0,it-measured) } ?: 0.0
  if(r.criticalFailures>0) reasons += "Critical benchmark failures"
  if(!r.privacySecurityPassed) reasons += "Privacy/security gate failed"
  if(regression>0.02) reasons += "Candidate score regressed by more than 2 percentage points"
  if(r.providerFailures>0) reasons += "Provider failures require review"
  val reviewCount=r.cases.count { it.critical }
  val run=EvalRun("eval_${UUID.randomUUID().toString().replace("-","").take(16)}",Instant.now().toString(),r.engineVersion,r.datasetVersion,r.configurationId,r.providerIds.distinct(),n,r.sampleSize,measured,r.baselineScore,regression,r.criticalFailures,r.privacySecurityPassed,r.avgLatencyMs,r.providerFailures,r.estimatedCost,reasons.isEmpty(),reasons,reviewCount)
  runs.add(run); while(runs.size>maxHistory) runs.removeAt(0)
  reasons.forEach { reviews.add(ReviewItem("review_${UUID.randomUUID().toString().take(12)}","quality_gate",run.id,it,Instant.now().toString())) }
  r.cases.filter { it.critical }.forEach { reviews.add(ReviewItem("review_${UUID.randomUUID().toString().take(12)}","holdout_review",it.id,"Critical/ambiguous case requires human review",Instant.now().toString())) }
  while(reviews.size>maxHistory*4) reviews.removeAt(0)
  run
 }
 private fun normalize(s:String)=s.trim().lowercase().replace(Regex("\\s+")," ").trimEnd('.','!','?')
 @Synchronized fun history()=runs.toList().reversed()
 @Synchronized fun reviewQueue()=reviews.filter { it.status=="pending" }.take(500)
}

@Serializable data class MemoryClaim(val id:String,val text:String,val domain:String,val source:String,val confidence:Double,val approved:Boolean=false,val lastVerified:String?=null,val expiresAt:String?=null,val status:String="active",val version:Int=1,val usedCount:Long=0)
@Serializable data class MemoryPolicy(val domain:String,val maxAgeDays:Int?=null,val reverifyAfterDays:Int?=null,val neverAutoDelete:Boolean=true)
@Serializable data class MaintenancePreview(val previewId:String,val createdAt:String,val kept:Int,val refreshDue:Int,val quarantined:Int,val duplicatesSuggested:Int,val softDeleteCandidates:Int,val destructiveConfirmationRequired:Boolean=true,val reasons:List<String>)
@Serializable data class MaintenanceRequest(val confirmPreviewId:String?=null,val confirmSoftDelete:Boolean=false,val storageQuotaRecords:Int=10000)
@Serializable data class MaintenanceReport(val previewId:String,val kept:Int,val refreshed:Int,val merged:Int,val quarantined:Int,val softDeleted:Int,val restored:Int,val reasons:List<String>,val completedAt:String)

/** Reversible lifecycle manager. Age alone never removes an approved claim. */
class MemoryLifecycleService {
 private val claims= linkedMapOf<String,MemoryClaim>(); private val history= mutableMapOf<String,MutableList<MemoryClaim>>(); private val previews= mutableMapOf<String,MaintenancePreview>(); private val deleted= mutableMapOf<String,MemoryClaim>()
 private val policies=mapOf("weather" to MemoryPolicy("weather",1,1),"market_price" to MemoryPolicy("market_price",1,1),"news" to MemoryPolicy("news",7,3),"software_version" to MemoryPolicy("software_version",90,30),"mathematics" to MemoryPolicy("mathematics",null,3650),"general" to MemoryPolicy("general",null,180))
 @Synchronized fun upsert(c:MemoryClaim):MemoryClaim { require(c.id.isNotBlank() && c.text.isNotBlank() && c.confidence in 0.0..1.0); history.getOrPut(c.id){ mutableListOf() }.add(claims[c.id] ?: c); claims[c.id]=c; return c }
 @Synchronized fun list()=claims.values.toList()
 @Synchronized fun policyDirectory()=policies.values.toList()
 @Synchronized fun preview(quota:Int=10000):MaintenancePreview {
  require(quota in 1..1000000)
  val refresh=claims.values.count { c -> val p=policies[c.domain] ?: policies.getValue("general"); c.status=="active" && p.reverifyAfterDays!=null && c.lastVerified==null }
  val quarantine=claims.values.count { it.status=="active" && (it.confidence<0.35 || it.status=="contradicted") }
  val dupes=claims.values.groupBy { it.text.trim().lowercase() }.values.count { it.size>1 }
  val excess=max(0,claims.size-quota)
  val p=MaintenancePreview("memprev_${UUID.randomUUID().toString().take(12)}",Instant.now().toString(),claims.size-refresh-quarantine,refresh,quarantine,dupes,excess,true,listOf("Expiry is domain-specific","Approved claims are never removed for age or inactivity alone","Duplicates are suggestions until reviewed","Soft deletion is reversible"))
  previews[p.previewId]=p; p
 }
 @Synchronized fun maintain(req:MaintenanceRequest):MaintenanceReport {
  val p=previews[req.confirmPreviewId] ?: throw IllegalArgumentException("Create a current preview before maintenance")
  var quarantined=0; var soft=0
  claims.values.toList().forEach { c ->
   if(c.status=="active" && c.confidence<0.2) { history.getOrPut(c.id){ mutableListOf() }.add(c); claims[c.id]=c.copy(status="quarantined",version=c.version+1); quarantined++ }
  }
  if(req.confirmSoftDelete) {
   require(req.confirmPreviewId==p.previewId) { "Explicit matching preview confirmation required" }
   val excess=max(0,claims.size-req.storageQuotaRecords)
   claims.values.filter { !it.approved && it.status=="quarantined" }.take(excess).forEach { c -> deleted[c.id]=c; history.getOrPut(c.id){ mutableListOf() }.add(c); claims.remove(c.id); soft++ }
  }
  MaintenanceReport(p.previewId,claims.size, p.refreshDue,0,quarantined,soft,0,listOf("Approved facts preserved","No age-only deletion","All removals are soft-deleted and restorable during retention"),Instant.now().toString())
 }
 @Synchronized fun restore(id:String):MemoryClaim? { val c=deleted.remove(id) ?: return null; claims[id]=c.copy(status="active",version=c.version+1); return claims.getValue(id) }
 @Synchronized fun versions(id:String)=history[id]?.toList() ?: emptyList()
}
