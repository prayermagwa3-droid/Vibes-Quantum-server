package com.vibes.quantum.server.quality

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class QualityMemoryTest {
 @Test fun measuredScoreUsesReferenceCasesAndBlocksRegression() {
  val q=QualityGateService()
  val run=q.evaluate(EvalRunRequest("2.7","bench-1",cases=listOf(
   EvalCase("1","facts","q","The answer.",candidateAnswer="The answer"),
   EvalCase("2","facts","q2","Correct",candidateAnswer="wrong")
  ),sampleSize=2,baselineScore=1.0,candidateScore=1.0))
  assertEquals(0.5,run.candidateScore)
  assertFalse(run.promoted)
  assertTrue(run.gateReasons.isNotEmpty())
 }
 @Test fun privacyFailureBlocksPromotionAndQueuesReview() {
  val q=QualityGateService(); val r=q.evaluate(EvalRunRequest("2.7","bench-1",cases=listOf(EvalCase("1","safety","q","ok",candidateAnswer="ok")),privacySecurityPassed=false))
  assertFalse(r.promoted); assertTrue(q.reviewQueue().isNotEmpty())
 }
 @Test fun approvedOldClaimsAreNotDeletedByPreviewOrMaintenance() {
  val m=MemoryLifecycleService(); m.upsert(MemoryClaim("claim1","A stable mathematical fact","mathematics","textbook",1.0,approved=true))
  val p=m.preview(); val report=m.maintain(MaintenanceRequest(confirmPreviewId=p.previewId,confirmSoftDelete=true))
  assertEquals(1,report.kept); assertEquals("active",m.list().single().status)
 }
 @Test fun lowConfidenceClaimsAreQuarantinedAndVersioned() {
  val m=MemoryLifecycleService(); m.upsert(MemoryClaim("claim2","uncertain claim","general","unknown",0.1))
  val p=m.preview(); val report=m.maintain(MaintenanceRequest(confirmPreviewId=p.previewId))
  assertEquals(1,report.quarantined); assertEquals("quarantined",m.list().single().status); assertTrue(m.versions("claim2").isNotEmpty())
 }
}
